

main_config  = {

  # terraform.tfvars

  org_prefix          = "nct"
  environment         = "dev"
  azure_location      = "South India"
  vm_size             = "Standard_B2als_v2"
 registry_name         = "nctdevregistryjdanuj"
resource_group_name   = "nct-dev-registry-rg"
  owner_name          = "jane-doe"
  cost_centre         = "CC-DEVOPS-007"
  app_service_name    = "nct-dev-app-web-jdme"

}