

variable "main_config" {
  type = object({
    org_prefix          = string
    environment         = string
    azure_location      = string
    vm_size             = string
   registry_name    = string
    resource_group_name = string
    owner_name          = string
    cost_centre         = string
    app_service_name    = string
  })

}



locals {
  
orgname =var.main_config.org_prefix
rgname = var.main_config.resource_group_name


  tags = {
    ProjectNCT = "INFRA-006"
    Owner      = "jane-doe"
    ManagedBy  = "terraform"
    CostCentre = "CC-DEVOPS-007"
    Team       = "platform-engineering"
  }

}


