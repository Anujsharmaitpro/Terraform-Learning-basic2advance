resource "azurerm_resource_group" "main_rg" {
  name = var.main_config.resource_group_name
  location =var.main_config.azure_location  
  tags = local.tags
}


resource "azurerm_container_registry" "main_container" {
  name = var.main_config.registry_name 
  resource_group_name = azurerm_resource_group.main_rg.name
  location = azurerm_resource_group.main_rg.location
  sku = "Basic"
  admin_enabled = true
tags = local.tags
}