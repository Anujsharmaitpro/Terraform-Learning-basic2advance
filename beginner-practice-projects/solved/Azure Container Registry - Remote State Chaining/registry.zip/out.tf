output "registry_login_server" {
  value = azurerm_container_registry.main_container.login_server
}

output "registry_name" {
  value = azurerm_container_registry.main_container.name
}

output "registry_admin_username" {
  value = azurerm_container_registry.main_container.admin_username
}

output "registry_admin_password" {
  value     = azurerm_container_registry.main_container.admin_password
  sensitive = true
}

output "resource_group_name" {
  value = azurerm_resource_group.main_rg.name
}