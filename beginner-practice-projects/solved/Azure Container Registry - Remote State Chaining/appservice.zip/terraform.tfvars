

main_config  = {

  # terraform.tfvars

  org_prefix          = "nct"
  environment         = "dev"
  azure_location      = "South India"
  vm_size             = "Standard_B2als_v2"
app_service_name      = "nct-dev-006-web-jdme"
resource_group_name   = "nct-dev-006-app-rg"
  owner_name          = "jane-doe"
  cost_centre         = "CC-DEVOPS-007"
  

}