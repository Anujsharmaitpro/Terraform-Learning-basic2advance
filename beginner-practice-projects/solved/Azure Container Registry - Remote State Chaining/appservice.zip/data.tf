data "azurerm_client_config" "current" {


}

data "terraform_remote_state" "registry" {
  backend = "azurerm"

  config = { 
     resource_group_name  = "shared-network-rg"
    storage_account_name = "terraformlabforazure" # Replace with your actual storage account name
    container_name       = "config"
    key                  = "registry.terraform.tfstate"
    # You need 4 arguments inside here:
    # 1. The resource group name of your storage account (as a quoted string)
    # 2. The storage account name (as a quoted string)
    # 3. The container name (as a quoted string)
    # 4. The exact state file key path you used in your backend configuration (as a quoted string)
  }
}