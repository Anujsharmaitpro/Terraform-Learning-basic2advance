resource "azurerm_resource_group" "app_main" {
  name     = local.rgname
  location = local.location
  tags     = local.tags
}

resource "azurerm_service_plan" "app_srv_plan" {
  name                = "nct-dev-006-plan"
  location            = azurerm_resource_group.app_main.location
  resource_group_name = azurerm_resource_group.app_main.name
  os_type             = "Linux"
  sku_name            = "F1"
  tags                = local.tags
}

resource "azurerm_linux_web_app" "wep_app" {
  name                = var.main_config.app_service_name
  resource_group_name = azurerm_resource_group.app_main.name
  location            = azurerm_resource_group.app_main.location
  service_plan_id     = azurerm_service_plan.app_srv_plan.id

  site_config {
    always_on = false
    
    application_stack {
      docker_image_name        = "nginx:latest"
      docker_registry_url      = "https://${data.terraform_remote_state.registry.outputs.registry_login_server}"
      docker_registry_username = data.terraform_remote_state.registry.outputs.registry_admin_username
      docker_registry_password = data.terraform_remote_state.registry.outputs.registry_admin_password
    }
  }

  app_settings = {
    # REMOVED: The 3 DOCKER_REGISTRY_SERVER keys to prevent provider conflict
    "WEBSITES_PORT"            = "8000"
    "WEBSITE_RUN_FROM_PACKAGE" = "1"
  }

  lifecycle {
    ignore_changes = [
      app_settings["WEBSITE_RUN_FROM_PACKAGE"]
    ]
  }
}