output "all_app_out" {
  value = {
name = local.rgname
  location = local.location
   app_service_name = var.main_config.app_service_name
  tags = local.tags

  }

}


output "app_service_url" {
  value       = "https://${azurerm_linux_web_app.wep_app.default_hostname}"
  description = "The live URL of the Linux Web App."
}

output "app_service_name" {
  value = azurerm_linux_web_app.wep_app.name
}

output "resource_group_name" {
  value = azurerm_resource_group.app_main.name
}

output "registry_connected_to" {
  value = data.terraform_remote_state.registry.outputs.registry_login_server
}